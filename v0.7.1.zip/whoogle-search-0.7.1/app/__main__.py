from .routes import run_app

run_app()
